package map;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*
 * 
 */

public class IteratorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> ls=new ArrayList<>();
		ls.add(2);
		ls.add(6);
		ls.add(1);
		ls.add(9);
		
		Iterator<Integer> itr=ls.iterator();
	
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}

		
		
		
		/*
		 *   ArrayList<Integer> list = new ArrayList<>();
        for (int i : list) {
            System.out.println(i);
        }
        Iterator<Integer> iterator = list.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        List<Integer> numbers = new ArrayList<>();
        numbers.add(1);
        numbers.add(2);
        numbers.add(3);
        numbers.add(4);
        numbers.add(5);
//        for (Integer number : numbers) {
//            if (number % 2 == 0) {
//                numbers.remove(number);
//            }
//        }
        Iterator<Integer> itr = numbers.iterator();
        while (itr.hasNext()) {
            Integer number = itr.next();
            if (number % 2 == 0) {
                itr.remove();
            }
        }
        System.out.println(numbers);
        ListIterator<Integer> listIterator = numbers.listIterator();
        while (listIterator.hasNext()){
            listIterator.next();
//            listIterator.set();
        }
		 */
	}

}
