package map;

import java.util.SortedMap;
import java.util.TreeMap;
/*
 * Sorted Map-> it is interface which is implemented by treemap class which stores value in sorted order according 
 *             to value of key either by natural sorting or by using comparator
 *             we can use map also in place of sorted map but sorted map has more inbuilt functions so that is advantage
 * 
 * Tree map is REd black tree means self balancing binary search tree so in this case it will have complexity log(n)
 * Navigable map is also an interface has more predefined functions used to find closest match.
 */

public class SORTEDmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedMap<Integer,String> st=new TreeMap<>(); // we can use navigable map also in place of sorted map, it gives more functions
		st.put(5,"Ram");                                  //like lower key, higher key, ceiling,floor..etc
		st.put(9,"kfrnkrn");
		st.put(1,"djknfkn");
		st.put(6,"njfff");
		st.put(8,"dljfdj");
		
		System.out.println(st);
		System.out.println(st.firstKey());
		System.out.println(st.lastKey());
		System.out.println(st.headMap(8));//excluding this key it will print all before this
		System.out.println(st.tailMap(6));//including frpom this key till last gets printed
		System.out.println(st.subMap(5,9));
		
		
	//	SortedMap<Integer,String> st1=new TreeMap<>((a,b)-> b-a); --> we can write comparator to print it in descending order
		
		
		

	}

}
