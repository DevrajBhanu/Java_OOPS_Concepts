package map;
//it gives the element in the way it is stored(Insertion Order)  in Double linked list so it becomes slow
//while iterating all the elements of linkedhashmap it will give the value of least used key then give others follwoing above rule.
//it is also is not thread safe and has all methods that hasmap had
// it hjave more varities like WeakLinkedHashMap & IdentityLinkedHAshMAp....
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Linkedhashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedHashMap<Integer, String> lnk=new LinkedHashMap<>();
		lnk.put(10, "Kaushal");
		lnk.put(30,"Kundan");
		lnk.put(7,"JNSKn");
		
		// we can put hashmap also in linkedhashmap
		HashMap<Integer,String> hm=new HashMap<>();
		hm.put(1, "Dev");
		hm.put(6, "Raj");
		hm.put(4, "Bhanu");
		hm.put(5, "Yash");
		hm.put(9, "Digvijay");
		LinkedHashMap<Integer, String> lnk2=new LinkedHashMap<>(hm);
		
		String in=hm.getOrDefault(5, "Me");//if map will not have that key then it will return value set in parametr
		System.out.println(in);
		hm.putIfAbsent(10, "Raju");
		System.out.println(hm);
		

	}

}
