package map;

import java.util.ArrayList;
import java.util.List;

/*
 * 
 
It is an interface that has method compareTo() which gives natural sorting of the collection
No need to pass custom comparators every time like in comparator we used to do by passing 2 parameters

To use comparable , it should be implemented in same class and overriden also and we can use only one 
comparable at a time and we cat write lambda expression for it because we can implement overriden method in lambda expression
 lambdas can't be used to implement interfaces that require you to override a method inside a class definition.

*/
   class student implements Comparable<student>
   {
	public int marks;
	public String name;
	 public student(int marks, String name)
	 {
		 this.marks=marks;
		 this.name=name;
	 }
	 public int getmarks()
	 {
		 return marks;
	 }
	 public String getname()
	 {
		 return name;
	 }

	 public int compareTo(student o)
	 {
		return o.name.length()-this.name.length(); 
	 }
}
 

public class comaparable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<student> ls=new ArrayList<>();
		ls.add(new student(100,"Sunyo"));
		ls.add(new student(200,"Giya"));
		ls.add(new student(50,"Suzuka"));
		ls.add(new student(70,"Doremon"));
		ls.sort(null);
		for(student s:ls)
		{
		System.out.println(s.getmarks()+" "+s.getname());
		}

	}

}
