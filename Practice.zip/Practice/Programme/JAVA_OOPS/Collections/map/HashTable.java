package map;

import java.util.Hashtable;
/*
 * Hashtable-> It is thread safe means its synchronized so it is slower than hashmap and it cant contain key and value
 *  as null values like in hashmap ,remaining everything is same as hashmap as this is also implementing map.
 *  
 *  it  is legacy class, 
 *  only linked list in case of collision
 */

public class HashTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Hashtable<Integer,String> hs=new Hashtable<>();
		hs.put(4,"Ramn");
		hs.put(1,"Shyam");
		hs.put(2,"back");
		
		System.out.println(hs);*/
		Hashtable<Integer,String> hs2=new Hashtable<>();
		
		  Thread t1 = new Thread(() -> {
	            for (int i = 1; i < 1000; i++) {
	                hs2.put(i, "Thread1");
	                // Optionally comment out the print line to avoid spamming console
	                // System.out.println("Thread1 calling");
	            }
	        });

	        Thread t2 = new Thread(() -> {
	            for (int i = 1000; i <= 2000; i++) {
	                hs2.put(i, "Thread2");
	            }
	        });

	        t1.start();
	        t2.start();

	        try {
	            t1.join();
	            t2.join();
	        } catch (InterruptedException e) {
	            System.out.println("Thread interrupted: " + e.getMessage());
	        }

	        System.out.println("Final size: " + hs2.size());  // Should be 2000
	    }	
	}


