package map;

import java.util.HashMap;
import java.util.*;

/*
 * Map is an interface that contains key value pair, and key will never be duplicate , if we give duplicate 
 * key like(2, Rahul) , (2, Ram) so Ram will be updated value for key 2. It is in uonorder order and not synchronized
 * 
 * Can have one null key and mutiple null values
 * 
 * In this every operation has almost (O(1)) time complexity bcoz it doesnt uses loop to iterate element except in case of collision
 * Key ,value pair are stored in hasmap using hashfunction , internally it is stored in the form of Array containing
 * 3 things key value and Node next if collison happeans.
 * 
 * Collision-> It happens when more than one value gets same index for multiple keys after hashing so then it will stored inside array as linked list upto some extent after that
 * if load increases then it uses Red black tree or balanced binary search tree which has time complexity of (O(logn)) as compared to linked list had (O(n))
 * 
 * Storing of data in array , so index is decided using hasing with the help of hashfunction ,and this index is also called as bucket
 
 */

public class hashmapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> hm=new HashMap<>();
		hm.put(1, "Dev");
		hm.put(6, "Raj");
		hm.put(4, "Bhanu");
		hm.put(5, "Yash");
		hm.put(9, "Digvijay");
		
		
		String str1=hm.get(6);
		System.out.println("Value at 6 key:"+str1);
		
		//System.out.println("Contains Key 5 :"+hm.containsKey(5));
		//System.out.println("Contains Value Dev: "+hm.containsValue("Dev"));
		
		Set<Integer> st=hm.keySet();//return all keys from hasmap
		for(int i:st)
		{System.out.println(i);
		}
		
	Set<Map.Entry<Integer, String>> st2 =hm.entrySet();//returns all key values pair from hashmap
	for(Map.Entry<Integer, String> k:st2)
	{
	 System.out.println(k.getKey()+" "+k.getValue());
	 //if we want to change all element to uppercase
	  k.setValue(k.getValue().toUpperCase());
	}
	
	System.out.println(hm);
	
		
	   
		

	}

}
