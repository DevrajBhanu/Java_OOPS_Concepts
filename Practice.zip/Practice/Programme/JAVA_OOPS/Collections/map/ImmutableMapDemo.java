package map;


import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
/*
 * Immutable map-> it can be changed updated , modified or resized so all the elements are fixed here 
 */

public class ImmutableMapDemo {
    public static void main(String[] args) {
        Map<String, Integer> map1 = new HashMap<>();
        map1.put("A", 1);
        map1.put("B", 2);
        Map<String, Integer> map2 = Collections.unmodifiableMap(map1);
        System.out.println(map2);
//        map2.put("C", 3); throws exception because we cant change immutable map
        Map<String, Integer> map3 = Map.of("Shubham", 98, "Vivek", 89);
        map3.put("Akshit", 88); // this will also give rror in runtime bcoz of method will return immutable map
        Map<String, Integer> map4 = Map.ofEntries(Map.entry("Akshit", 99), Map.entry("Vivek", 99));


    }
}