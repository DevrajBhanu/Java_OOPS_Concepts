package list;

import java.util.Arrays;
import java.util.LinkedList;

/*
 * it mainly contains nodes which consists value and pointers(reference of next address)
 * It is of three types-Double,Circular & Linear linked list
 * It is not stored in contiguous memory so fetching element through index is difficult(O(n))
 * Insertion and deletion is easy as we just had to change reference of node to next/inserted/deleted node ((O(1))
 */

public class linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> ls=new LinkedList<>();
		ls.add(2);
		ls.add(6);
		ls.add(9);
		System.out.println("LinkedList: "+ls);
		ls.addFirst(10);
		ls.addLast(35);
		System.out.println("Modified LinkedList after add first & Last : "+ls);
		System.out.println("Take first Element: "+ls.getFirst());
		ls.remove();//removes first element
		System.out.println("LinkedList after remove func: "+ls);//it removes first element
        ls.removeIf(x->x%2==0);
        System.out.println("After remove if LinkedList: "+ls);
        
        
        LinkedList<Integer> ls2=new LinkedList<>(Arrays.asList(10,9,40,35));
        ls2.removeAll(ls);
        System.out.println("After remove all ls from ls2: "+ls2);
        
	}

}
