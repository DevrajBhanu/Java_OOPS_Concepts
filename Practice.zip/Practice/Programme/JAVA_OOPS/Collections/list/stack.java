package list;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Stack;

/*
 * Stack -> Last In First Out-> LIFO ->It extends vector class means it is also synchronised so it is thread safe
 * Arraylist,linkedlist,vector->are in sequential way but stack are in LIFO
 * 
 * we can also use linkedlist as stack when we dont need thread safety bcoz it also has addlast,addfirst, getfirst,getlast fuctions
 * 
 */

public class stack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer> st=new Stack<Integer>();
		st.push(10);
		st.push(9);
		st.push(20);
		
		st.pop();//deletes last element
		int k=st.peek();//returns last element
		System.out.println(k);
		System.out.println(st);
		
		//linked list as array
		LinkedList<Integer> ls=new LinkedList<>();
		ls.addLast(10);//push
		ls.addLast(9);
		ls.addLast(29);
		
		ls.removeLast();//pop
		System.out.println(ls);
		
		

	}

}
