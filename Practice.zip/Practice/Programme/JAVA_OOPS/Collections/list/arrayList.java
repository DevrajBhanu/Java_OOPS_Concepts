package list;
import java.util.*;
/*
 * List-> It stores elements in ordered collection means it stores element at same index given 
 *  and can contain duplicates
 *  
 * ArrayList->it is used to store element when the size of list is not fixed hence it can increase its size dynamically
 * not like Array
 * 
 * Initial arraylist size is 10, so if we add extra element it will get resized to 1.5 times of the current capacity and
 * gets copied to new array
 */

public class arrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> ls1=new ArrayList<Integer>();
		// System.out.println(ls.get(0));--> retuirn error as no element is there
		ls1.add(7);
		ls1.add(2);
		ls1.add(3);
		ls1.add(1,6);//it will add the value 6 at index 1
		ls1.set(0, 7);//it will replace the value at index 7
		System.out.println(ls1);
		System.out.println(ls1.contains(2));
		
		//creating array list in different ways
		String str[]= {"Ram","Siyam,","Jiyan"};
		List<String> ls2=Arrays.asList(str);
		// ls2.add("adding");-->it is unextendable so we cant add any new element hene we can only replace hence gives error in runtime
		ls2.set(1,"can");
		System.out.println(ls2);
		
		List<Integer> ls3=List.of(1,3,5);//--> it is modifiable and unextendable also so we can use it in new list to use anywhere		
		ls1.addAll(ls3); //here we are adding list3 into list1 
		System.out.println(ls1);

		List<Integer> ls4=new ArrayList<Integer>(ls1);
		System.out.println(ls4);
		
	 //Remove by index
     ls4.remove(2);	
	System.out.println(ls4);
	
	//Remove by value
	ls4.remove(ls4.get(2));
	System.out.println(ls4);
		
	    //converting list to array
	    Integer arr[]=ls4.toArray(new Integer[0]);// or we can write as Object arr[]=ls4.toArray(); 
	    for(int k:arr)
	    {
		System.out.println(k);
	    }
	    
	    ls4.sort(null); // or we can write it as Collections.sort(ls4)
	    System.out.println(ls4);
		
		
	}

}
