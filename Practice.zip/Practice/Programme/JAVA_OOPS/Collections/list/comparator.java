package list;

import java.util.ArrayList;
import java.util.*;

/*
 * Comparator->Comparator is an interface in java.util package used to define a custom order for sorting objects.
    It lets you specify how two objects should be compared without changing the objects' class.
    
    It has one main method to implement:
    int compare(T o1, T o2);
    The method compares two objects o1 and o2 and returns:
     1.)A negative integer if o1 should come before o2
     2.)0 if they are equal
     3.)A positive integer if o1 should come after o2
 */
  //we can define comparator in our own way also like:
class Stud
{   public int marks;
	public Stud(int marks)
	{
		this.marks=marks;
	}
	public int getmarks()
	{
		return marks;
	}
}
 class myComparator implements Comparator<Stud>
{
	public int compare(Stud s1,Stud s2)
	{
		return s2.marks-s1.marks;
	}
}

public class comparator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> ls=new ArrayList<Integer>();
		ls.add(1);
		ls.add(9);
		ls.add(3);
		ls.add(6);
		
		ls.sort(null);// it will by default arrange in ascending order
		System.out.println(ls);
		
		ls.sort((a,b)-> b-a); // here we are defining comparator method using lambda expression in descending order sorting
		System.out.println(ls);
		
		List<Stud> ls2=new ArrayList<>();
		ls2.add(new Stud(17));
		ls2.add(new Stud(10));
		ls2.add(new Stud(8));
		ls2.add(new Stud(40));
		
		ls2.sort(new myComparator());
		//or we can write above line  as : Collections.sort(ls2, new NameComparator());
		//or we can write above line  as in form of lambda as: Collections.sort(ls2, (s1, s2) -> s1.name.compareTo(s2.name)); 
		
	    for(Stud s:ls2)
	    {
	    	System.out.print(s.getmarks()+" ");
	    }
	}

}
