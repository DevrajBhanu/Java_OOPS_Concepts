package list;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/*can read and write at one time
 * if we make any changes in list while reading so new copyof list will be created without affecting existing one
 * once reading will be completed then old list will refer to new copied list to mak sure changes are reflecting in furture references
 */

public class CopyonwriteArraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    List<Integer> ls=new CopyOnWriteArrayList<Integer>(Arrays.asList(1,3,4,5));
    System.out.println("Initial List:"+ls);
    for(int i=0;i<ls.size();i++)
    {  System.out.print(ls.get(i)+" ");
    	if(ls.get(i)==4)
    	{
    		ls.add(7);
    		System.out.println();
    		System.out.println("7 is added");
    	}
    	
    }
    System.out.println("Updated List:"+ls);
    
    
	}

}
