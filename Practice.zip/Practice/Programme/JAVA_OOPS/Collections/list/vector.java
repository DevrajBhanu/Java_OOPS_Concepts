package list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

/*
 * Vector is same as array list only the difference is it is thread safe and synchronised 
 * so, if we want to have single threaded function then we use arraylist and if we need multiple threaded func then we use vector
 *
 *Initial capacity is 10, by default it capacity increases by 2x, or we can give increment in capacity as argument while defining
 * It has no many predefined functions.
 */

public class vector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Vector<Integer> vc=new Vector<>(15,3);//here 15 is sinitaial capacity and 3 is increment in capacity once element increases more than initial capacity so it will be changed to 15+3=18
		vc.add(5);
		vc.add(25);
		vc.add(55);
		vc.add(85);
		System.out.println(vc);
		System.out.println(vc.capacity());
		
		Vector<Integer> vc2=new Vector<>(Arrays.asList(1,4,6,2,9));
		System.out.println(vc2);
		
		List<Integer> ls1=new ArrayList<Integer>();
		ls1.add(7);
		ls1.add(2);
		ls1.add(3);
		Vector<Integer> vc3=new Vector<>(ls1);
		System.out.println(vc3);*/
		
		Vector<Integer> vc4=new Vector<Integer>();
		Thread t1=new Thread(()->
				{
					for(int i =0;i<1000;i++)
				    {
					vc4.add(i);
				    }	
				});
		Thread t2=new Thread(()->
		{
			for(int j=0;j<1000;j++)
		    {
			vc4.add(j);
		    }	
		});
        t1.start();
        t2.start();
 
            try
         {t1.join();
         t2.join();}
 catch(Exception e)
 {
	 System.out.println(e.getMessage());
 }
     System.out.println("Capacity after thread runs: "+vc4.size());   
	}

}
