package set;

import java.util.HashSet;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentSkipListSet;

//it does not contains duplicate element and remaining everything is same as hashmap and its types

//Set is a collection that cannot contain duplicate elements
// faster operations
// Map --> HashMap, LinkedHashMap, TreeMap, EnumMap
// Set --> HashSet, LinkedHashSet, TreeSet, EnumSet
public class set_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> st=new HashSet<>();
		st.add(1); //Here we use add menthod because it extends collection interface
		st.add(8);
		st.add(3);
		
		System.out.println(st);
		
		 NavigableSet<Integer> set = new TreeSet<>();
	        set.add(12);
	        set.add(1);
	        set.add(1);
	        set.add(67);
	        System.out.println(set);
	        System.out.println(set.contains(12));
	        System.out.println(set.remove(67));
	        set.clear();
	        System.out.println(set.isEmpty());
	        for(int i: set){
	            System.out.println(i);
	        }

	        // for thread safety

	        Set<Integer> set1 =  new ConcurrentSkipListSet<>();

	        // unmodifiable

	        Set<Integer> integers = Set.of(1, 2, 3,4,5,6,7,8,9,54,4323,545,4545);

		
		
		
		
		
		

	}

}
