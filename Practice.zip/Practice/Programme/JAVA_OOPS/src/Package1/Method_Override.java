package Package1;

class abc
{
	public void method()
	{
		System.out.println("Method of class A");
	}
}

class bcd extends abc
{
	/*@Override
	public void method()
	{
		System.out.println("Overridden Method of class B");	
	}*/
}
public class Method_Override {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bcd obj=new bcd();
		obj.method();   // if overriddden method will not be present in class b then it will execute method of parent class  

	}

}
