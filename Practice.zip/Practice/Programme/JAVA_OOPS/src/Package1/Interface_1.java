package Package1;
/*Rule 3: Multiple Inheritance rule
 * If a class implements two interfaces, and those two interfaces have the default method with 
 * the same signature, then the class can do one of the two below things to resolve this conflict.
 * Otherwise, the compilation fails so in this case: 
 *1.Provide its own implementation
 *2.Call to a specific interface’s default method
 */
interface Hello {
    default void sayIt() {
        System.out.println("Hello");
    }
}

interface Hi {
    default void sayIt() {
        System.out.println("Hi");
    }
}
class Interface_1 implements Hi, Hello {
    
    @Override             // if we cant override then it will come compile time error
    public void sayIt() {
        Hi.super.sayIt(); // Call the default method from a specific interface
        
    }
    

    public static void main(String[] args) {
        new Interface_1().sayIt(); // Hi
    }

	}
