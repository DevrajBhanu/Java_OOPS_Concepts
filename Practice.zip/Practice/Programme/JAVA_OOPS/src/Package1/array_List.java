package Package1;
/*
 * Array list: It is dynamic which means size is not fixed like array.It gives flexibility to add and 
 * remove elements. It has so many predefined functions to use which is restricted in case of array.
 * 
 * Linked list and Array Dequeue is almost same just some additional predefined functions are there
 * 
 * Linked list have functions like addFirst, getFirst, addLast, getLast & here insertion and deletion is fast
 *    because just we have to delink and link the new data to be inserted and same for deletion but here random access is difficult as 
 *    compared to Array and Arraylist
 *    
 * ArrayDequeue have functions like addFirst, getFirst, addLast, getLast
 */

import java.util.ArrayList;

public class array_List {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> al=new ArrayList<Integer>(); // here we can give size also in argument as initial capacity of arraylist
        al.add(1); 
        al.add(2);
        al.add(3);
        
        System.out.println(al.indexOf(3));//it will return the index of particular element
        al.add(1, 43); //43 will be added to 1st index  moving the 1st index existed element to right
       // al.clear(); // it will remove all elements
        System.out.println(al);
        
        /* or we can use it as for loop like:
         * 
         * 
         */for(int i=0;i<al.size();i++)
         {
        	 System.out.print(al.get(i)+" ");
         }
         System.out.println();

       
        ArrayList<Integer> al2=new ArrayList<Integer>();
        al2.addAll(al); // it will add all the elements of al to al2 arraylist
        System.out.println(al2);
        
        /* or we can use it as for loop like:
         * 
         */
	}

}
