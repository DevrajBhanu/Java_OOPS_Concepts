package Package1;
/*
 * Rule 2: Sub Interface takes priority
 * If two interface A and B have the same default method, 
 * and B extends A, then B’s default method takes the priority over A’s default method
 */
interface Hellooo {
    default void sayIt() {
        System.out.println("Hello");
    }
}

interface Hii extends Hellooo {
    default void sayIt() {
        System.out.println("Hi");
    }
}
class Interface3 implements Hii {

    public void printMessage() {
        sayIt();
    }

    public static void main(String[] args) {
        new Interface3().printMessage(); // Prints 'Hi'
    }
}

