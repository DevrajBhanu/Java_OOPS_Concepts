package Package1;
import java.util.*;

/* I have created a custom exception (Myexception) , but we can use predefined 
 * exceptions also like Arithmetic,Nullpointer... by extending exception class and 
 * throwing exception using throw keyword
 * 
 * Exceptions have some methods some of them are:- getMessage, toString, printStackTrace....
 */


class  Myexception extends Exception
{   @Override
	public String getMessage()
	{
		//return super.getMessage()+" toMessage is called";
		return "Age is not valid";
	}
/*    
@Override
    public String toString()
	{
		return super.toString()+" toString method is called";
	}
	*/
}

public class Exception_Class 
{
	public static void main(String args[]) throws Myexception
	{
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		if(age<9)
		{
			//try
			//{
				throw new Myexception();
				//throw new ArithmeticException("Age is not Valid");
			//}
			
		
		/*catch(Exception e) 
		{
			System.out.println(e.getMessage());
			System.out.println(e.toString());
			e.printStackTrace();
		}
		*/
	}
	  
  }
}


