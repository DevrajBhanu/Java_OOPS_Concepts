package Package1;
/*
 * Anonymous Class: It is used when you dont want to declare class and dfined it with members and all, so you can use
 * anonymous class where in one line you can create, instantiate and define it.
 * 
 * A normal class can implement any number of interfaces but the anonymous inner class can implement 
 * only one interface at a time.
 * 
 *A regular class can extend a class and implement any number of interfaces simultaneously. But anonymous 
 *Inner class can extend a class or can implement an interface but not both at a time.
 
 *For regular/normal class, we can write any number of constructors but we can't write any 
 *constructor for anonymous Inner class because the anonymous class does not have any name and while defining constructor class name
 *and constructor name must be same.
 */

interface i
{
	public void meth1();
	public void meth2();
}
public class Anonymous_Class {
	i obj=new i() {
		
		@Override
		public void meth2() {
			// TODO Auto-generated method stub
			System.out.println("Meth1");
			
		}
		
		@Override
		public void meth1() {
			// TODO Auto-generated method stub
			System.out.println("Meth1");
		}
	};

}







//Java program to illustrate creating an immediate thread
//Using Anonymous Inner class that extends a Class

//Main class
class MyThread {

 // Main driver method
 public static void main(String[] args)
 {
     // Using Anonymous Inner class that extends a class
     // Here a Thread class
     Thread t = new Thread() {
       
         // run() method for the thread
         public void run()
         {
             // Print statement for child thread
             // execution
             System.out.println("Child Thread");
         }
     };

     // Starting the thread
     t.start();

     // Displaying main thread only for readability
     System.out.println("Main Thread");
 }
}






//Java program to illustrate defining a thread
//Using Anonymous Inner class that define inside argument

//Main class
class MyThread1 {
 // Main driver method
 public static void main(String[] args)
 {
     // Using Anonymous Inner class that define inside
     // argument
     // Here constructor argument
     Thread t = new Thread(new Runnable() {
       
         public void run()
         {
             System.out.println("Child Thread");
         }
     });

     t.start();

     System.out.println("Main Thread");
 }
}
