package Package1;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class Date_Time {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		//Using Date Class
		Date d=new Date();
		System.out.println(d); 
		
       
		
		//Using Calendar Instance
		Calendar c = Calendar.getInstance();
        // Print corresponding instances by passing
        // required some as in arguments
		System.out.println("Timezone"+c.getTimeZone());
		System.out.println("Timezone"+c.getTimeZone().getID());
        System.out.println("Day of week : "+ c.get(Calendar.DAY_OF_WEEK));
        
        
       
        
       
        //Using SimpleDateFormat
        SimpleDateFormat ft= new SimpleDateFormat("dd-MM-yyyy");
        String str = ft.format(new Date());
        // Printing the formatted date
        System.out.println("Formatted Date : " + str);
        
        
       
        
        //Using LocalDate, LocalTime, LocalDateTime
        LocalDate currentDate = LocalDate.now();
        System.out.println("Current date: " + currentDate);
        // Current time
        LocalTime currentTime = LocalTime.now();
        System.out.println("Current time: " + currentTime);
        // Current date and time
        LocalDateTime currentDateTime = LocalDateTime.now();
        System.out.println("Current date and time: "+ currentDateTime);
        
        
        
       
        
        //Using System Clock
        Clock systemClock = Clock.systemDefaultZone();
        // Get the current instant using the clock
        System.out.println("Current instant: " + systemClock.instant());


	}

}
