package Package1;

public class Precedence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int d=10*10-4*3*2/2*3;
		int a=2; int b=3;
		int d= ++a*a/b;
		
		System.out.println(a+" "+d);

	}

}
