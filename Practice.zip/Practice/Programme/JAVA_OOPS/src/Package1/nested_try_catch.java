package Package1;

public class nested_try_catch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int arr[]=new int[3];
	
    try
   {
	 System.out.println("nested Try");
	 try
	 {
		 System.out.println(arr[9]);
	 }
	 catch(ArrayIndexOutOfBoundsException e)
	 {
		 System.out.println(e);
	 }
   }
	catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
