package Package1;
public class Rough
{
	protected int n;
	protected void call()
	{
		System.out.println("Protected members");
	}
}