package Package1;
class Journal
{
	public Long id;
	public String title;
	public void setid()
	{
		this.id=id;
	}
	public void settitle()
	{
		this.title=title;
	}
	public Long getid()
	{
		return id;
	}
	public String gettitle()
	{
		return title;
	}
}
public class Rough<Journal>
{ 
	public static void main(String args[])
	{
		Journal obj=new Journal();
		Map<Long,Journal>=new HashMap<>();
	}
}