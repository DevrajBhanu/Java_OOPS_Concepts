package Package1;
/*
 * String Buffer: it is slow , mutable and  thread safe  Initially 16 bit of space will be allocated if it gets full then again double of 16 and so on 
 * memory will be allocated
 * 
 * String Buffer: It is mutable and fast  but not  thread safe  , so to make it thread safe we have to use it in 
 * synchronized method or Atomic variable should be used in thread call.
 */

public class stringBuffer_stringBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer bf=new StringBuffer("Ram");
		bf.insert(2,"jmdkj").reverse().append("cdf");// multiple method we can use in one line which gives us multi chaining feature
		System.out.println(bf);
		bf.append(",ndkjndskn");
		System.out.println(bf);
		
		
		

	}

}
