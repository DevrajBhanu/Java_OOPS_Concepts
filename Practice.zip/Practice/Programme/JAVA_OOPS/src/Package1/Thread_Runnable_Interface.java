package Package1;

class thread1 implements Runnable
{   int i=0;
	public void run()
	{
		while(i<=400)
		{
		System.out.println("Thread1");
		i++;
		}
	}
}

class thread2 implements Runnable
{   int i=0;
	public void run()
	{
		while(i<=400)
		{
		System.out.println("Thread2");
		i++;
		}
	}
}
public class Thread_Runnable_Interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		thread1 bullet1=new thread1();
		thread2 bullet2=new thread2();
		
		Thread gun1=new Thread(bullet1);
		Thread gun2=new Thread(bullet2);
		
		gun1.start();
		gun2.start();

	}

}
