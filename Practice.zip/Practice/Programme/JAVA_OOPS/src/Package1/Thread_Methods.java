package Package1;
/*
 * join() - it is used to set priority to execute first thread using join method then others
 * sleep(milliseconds) - to pause thread for milliseconds given in parameter
 * getPriority()-  gives the priority set in thread
 * setPriority()- used to set the priority in thread
 * getState()- return thread is in NEW or Blocked or Runnable state
 */

class myThread4 extends Thread
{
	public void run()
	{   int i=0;
	   while(i<600) 
	   {
		System.out.println("My Thread 1");
		try
		{
		Thread.sleep(400);
		}
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
		i++;
	   }
	}
}
class myThread5 extends Thread
{
	public void run()
	{   int i=0;
	   while(i<600) 
	   {
		System.out.println("My Thread 2");
		i++;
	   }
	}
}

public class Thread_Methods {

	public static void main(String args[])
	{
		myThread4 t1=new myThread4();
		myThread5 t2=new myThread5();
		
		t1.start();
		try
		{
		t1.join();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		t2.start();
	}
}
