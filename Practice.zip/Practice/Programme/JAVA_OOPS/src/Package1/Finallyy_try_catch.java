package Package1;

/*
 * finally--> finally block of code will be executed at any situation
 */

public class Finallyy_try_catch {
	
	public static int greet()
	{
		try
		{
			int b=10/0;
			return b;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("Finally block executed");
		}
		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        greet();
	}

}
