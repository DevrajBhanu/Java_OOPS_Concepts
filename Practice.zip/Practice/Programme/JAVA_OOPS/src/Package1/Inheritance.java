package Package1;

/*Java doesn't support multiple inheritance aligns with its core prinicples of the simplicity, 
 * reliability and maintainability empowering the developer can build the concise class hierarchy. 
 * Java can provides the alternative mechanisms such as the interfaces and composition to 
 * achieve code reuse and extensiblity while avoiding the multiple inheritance
 */
/* Multiple inheritance is not supported because if one child class inherits from two parent class having same method name then
 * while calling that method compiler will get confused
 */

 class parent1
{
	int x;
	public void setX(int x)
	{
		this.x=x;
	}
	
	public int getX( )
	{
		System.out.println("Parent class");
		return x;
	}
	
}
 
 class Derived12 extends parent1
 {
	 int y;
	 public void setY(int y)
	 {
		 this.y=y;
	 }
	 public int getY()
	 {
		 return y;
	 }
 }
 class Derived21 extends Derived12
 {
	/* public void setX(int x)
		{
			this.x=x;
		}
		
		/*public int getX( )
		{  
			System.out.println("Derived class2");
			return x;
		}
		*/
		
 }
public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parent1 d;
		d=new Derived21();// so in this case only overridden method  which is inherited in child class but we cant access data members  so this we can access with parent reference and child object
		 /* in this case it is known as object upcasting  where we are keeping Parent class reference in child class object
		  * if we want to access all methods and members so we have to create object of child class with child object reference only 
		  */
		
		d.setX(10);
		//d.setY(40);
		System.out.println(d.getX());
		//System.out.println(d.getY());

	}

}
