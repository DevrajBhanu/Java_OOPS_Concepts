package Package1;

public class Array
{
	public static void main(String args[])
	{
		//ways of declaring array
		int arr[]=new int[5];//Declaration + Memory Allocation
		
		int arr1[];//Declaration
		arr1=new int[5];//Memory Allocation
		
		int arr2[]= {1,2,3,4,5};//Declaration + Initialization
		
		//MultiDimesiional Array
		int arr3[][]=new int[2][3];
		for(int i=0;i<arr3.length;i++)
		{
			for(int j=0;j<arr3[i].length;j++)
			{
				arr3[i][j]=1;
			}
		}
		/*for(int i=0;i<arr3.length;i++)
		{
			for(int j=0;j<arr3[i].length;j++)
			{
				System.out.print(arr3[i][j]);
			}
			System.out.println();
		}*/
		
		for(int element[]:arr3)
		{
			for(int ele:element)
			{
				System.out.print(ele);
			}
			System.out.println();
		}
		
		/*if array is passed as argument in static method so it is passed by reference - means if we 
		                   changes value in method original array value also changes.*/
	
}

}


/* n = 4

   1
  121
 12321
1234321
 12321
  121
   1
   
   */

























