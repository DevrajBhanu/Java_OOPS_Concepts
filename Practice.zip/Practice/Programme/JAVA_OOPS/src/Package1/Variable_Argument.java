package Package1;

public class Variable_Argument {

	static int sum(int x,int ...arr)  //int ...arr will be treated as int arr[], x is used to provide restriction
	{  int sum=x;                       //  that minimum one argument is required to pass as parameter to call method
		for(int elem:arr)
		{
			sum=sum+elem;
		}
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int result=sum(1,2,3,4,5);
        int result1=sum(2,3,5);
        System.out.println(result);
        System.out.println(result1);
	}

}
