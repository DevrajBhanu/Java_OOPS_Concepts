package Package1;
/*
 * Runtime Polymorphism in Java known as Dynamic Method Dispatch. It is a process in which a 
 * function call to the overridden method is resolved at Runtime. This type of polymorphism is 
 * achieved by Method Overriding. Method overriding, on the other hand, occurs when a derived
 *  class has a definition for one of the member functions of the base class. That base function 
 *  is said to be overridden.
 */
//Java Program for Method Overriding

//Class 1
//Helper class
class Parent4 {

 // Method of parent class
 void Print() {
     System.out.println("parent class");
 }
}

//Class 2
//Helper class
class subclass1 extends Parent4 {

 // Method
 void Print() { 
   System.out.println("subclass1"); 
 }
}

//Class 3
//Helper class
class subclass2 extends Parent4 {

 // Method
 void Print() {
     System.out.println("subclass2");
 }
}

//Class 4
//Main class
class Runtime_Polymorphism {

 // Main driver method
 public static void main(String[] args) {

     // Creating object of class 1
     Parent4 a;

     // Now we will be calling print methods
     // inside main() method
     a = new subclass1();
     a.Print();

     a = new subclass2();
     a.Print();
 }
}


