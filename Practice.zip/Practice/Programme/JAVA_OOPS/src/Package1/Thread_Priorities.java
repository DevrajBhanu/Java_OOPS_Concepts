package Package1;
/*
 * There are 3 priorities level - MAX-10, MIN-1, NORM-5
 * but sometimes priorities depends on OS also 
 */

class priority extends Thread
{
	priority(String name)
	{
		super(name);
	}
	public void run()
	{  int i=0;
		while(i<40)
		{
			System.out.println(this.getName());
			i++;
		}
		
	}
}
public class Thread_Priorities {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		priority t1=new priority("Thread1"); 
		priority t2=new priority("Thread2");
		priority t3=new priority("Thread3");
		priority t4=new priority("Thread4");
		priority t5=new priority("Thread5");
		
		t1.setPriority(Thread.MAX_PRIORITY); // OR we can write as:  t1.setPriority(10);
		t2.setPriority(Thread.MIN_PRIORITY); // OR we can write as:  t2.setPriority(1);
		t3.setPriority(Thread.NORM_PRIORITY); // OR we can write as: t3.setPriority(5);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		
		
		t1.getPriority();// it will return the priority set in thread --> return 10
		

	}

}
