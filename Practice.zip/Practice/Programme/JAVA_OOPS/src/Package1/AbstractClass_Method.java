package Package1;
/* if we create abstract method in any class then we have to make that class also abstract-it will
 * contain abstract and non abstract methods also & we can't create object of abstract class
  Abstract class  can have parameterized constructors and the default constructor is always present in an abstract class
  Abstract method- a method which is defined without its implementation and its implementation will be provided in class inheriting it
*/
abstract class parent3
{
	 abstract public void call(int x);
	 abstract public void call2(int x);
	 
	 public void parent_method()
	 {
		 System.out.println("Non - Abstract Parent3 Method");
	 }
	
}
  abstract class child3 extends parent3
{
	  public void call(int x)
  	  {
  		  System.out.println("Value from child4 class "+x);
  	  }
	 public void child_method()
	 {
		 System.out.println("Non - Abstract child3 Method");
	 }
	
}
   class child4 extends child3
  {
	   public void call2(int x)
	  	  {
	  		  System.out.println("Value from child4 class call2 func  "+x);
	  	  }
		
  	 public void child_method()
  	 {
  		 System.out.println("Non - Abstract child4 Method");
  	 }
  	 
  	
  }
 
public class AbstractClass_Method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*child4 obj=new child4();
		obj.call(10);
		obj.child_method();
		obj.parent_method();
		*/
		
	child3 obj=new child4(); // we can create reference of abstarct class but not object to call overridden method
	obj.child_method();
	obj.parent_method();
	obj.call(90);
	obj.call2(60);
	

	}

}
