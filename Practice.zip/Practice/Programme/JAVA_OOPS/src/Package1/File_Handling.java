package Package1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

/*
 *  byte stream- It take value as byte which is 8 bit range is limited such as img file, audio file.
 *  System.in()-> it is in byte stream which is taking input through keyboard from console
 *  
 *  System.in = byte stream (InputStream)
    InputStreamReader = converts byte stream to character stream (Reader)
    BufferedReader = buffers characters and adds convenient methods (like readLine())
 *  
 *
 */

public class File_Handling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
		{  
			/*
			//byte to char stream and then reading that char stream
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter Characters");
			String str=br.readLine();
			System.out.println(str);
			*/
			
			//outputstream Writer to print output on console
			OutputStreamWriter os=new OutputStreamWriter(System.out);
			os.write("dehvdjhebcfhjbrwk");
			os.write(12345);
			
			
			
			
			
			//creating and writing into file
			File fl=new File("C:\\Users\\devraj.bhanu.MPHASIS\\Desktop\\Practice\\Programme\\JAVA_OOPS\\src\\Package1\\Filex.txt");
			if(fl.createNewFile())
			{
			 System.out.println("File is created Successfully!!");
			}
			
			//Writing into file
			FileWriter writer=new FileWriter(fl);
            writer.write("My name is Devraj");
            writer.close();
            
            //Reading from File
            FileReader fr=new FileReader("C:\\\\Users\\\\devraj.bhanu.MPHASIS\\\\Desktop\\\\Practice\\\\Programme\\\\JAVA_OOPS\\\\src\\\\Package1\\\\Filex.txt");
            int asci=fr.read();
            while(fr.ready())
            {
             System.out.print((char)asci);	
             asci=fr.read();
            
            }
            
            
          
            //Alternative way Reading from file
           /* Scanner sc=new Scanner(fl);
            while(sc.hasNextLine())
            {
            	String str=sc.nextLine();
            	System.out.println(str);
            }
            sc.close();
  
           if(fl.delete())
           {
        	   System.out.println("File is deleted Successfully!!");
           }  
           */        
           
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
		
				

	}

}
