package Package1;
/*
 * throw: The throw keyword is used to explicitly throw an exception from a method or block of 
 *         code. 
   throws: The throws keyword is used in method declaration to indicate that a method may
           throw exceptions.
 */

class  NegativeRadiusException extends Exception
{   @Override
	public String getMessage()
	{
		return "Radius cannot be Negative";
	}

}


class circle1
{
	public double radius(double r) throws NegativeRadiusException
	{
		if(r<0)
		{
			throw new NegativeRadiusException();
		}
		double radius=Math.PI*r*r;
		return radius;
	}
}

public class throw_throws {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		circle1 obj=new circle1();
		try 
		{
		 double r= obj.radius(-2);
		 System.out.println("Area is"+r);
	    }
		catch(Exception e)
		{
			System.out.println(e+""+e.getMessage());
		}

 }
}	
