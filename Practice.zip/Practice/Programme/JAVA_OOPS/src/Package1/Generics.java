package Package1;

import java.util.ArrayList;
 class Boxes<T, K>
{
	private T value;
	public K[] arr;
	public Boxes(int size)
	{
		arr = (K[]) new Object[size];
	}
	public void setValue(T value)
	{
		this.value=value;
	}
	public T getValue()
	{
		return value;
	}
	public K returnrArray(int ind)
	{
		return arr[ind];
	}
	public void setArray(K elem,int ind)
	{
		this.arr[ind]=elem;
	}
	
}

public class Generics 
{
	public static void main(String args[])
	{
		Boxes<Integer,Integer> obj=new Boxes<>(4);
		obj.setValue(1);
		int k=obj.getValue();
		System.out.println(k);
		
		obj.setArray(10, 0);
		System.out.println(obj.returnrArray(0));
		
		
	}

	
	
	/*
	 * we can write program in above way by using generics
	 * public static void main(String[] args) {
	 
		// TODO Auto-generated method stub
		ArrayList al=new ArrayList();
		al.add("abc");
		al.add(1);
		Object o=al.get(1);
		// String o=al.get(1);//Here we can't give string as its object type bcoz we didnot declared arraylist
		                      //data type while declaring so its not datatype safe as we cant given any datatype
		                      //in this case we have to do downcasting from object to particular data type t
		System.out.println(o);
		//String st=(al.get(0).toString());
		System.out.println(al.get(1));
		
		*/

	}


