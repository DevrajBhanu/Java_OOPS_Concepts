package Package1;

/*There no difference in initializing the string, either by direct assignment (String a = �Java�) or explicit call to constructor (String a = new String(�Java�)).
The only difference lies on JVM side. In first case, Object String �Java� is created in heap and reference is assigned to variable a.
Second case (String a = new String(�Java�)) just serves as a copy constructor that takes a String as an argument and creates a new instance that represents the same string of characters. Further more first string created (�Java�) is ready for garbage collection on the very next line.

The concept would be more illustrated by following Example:*/

// String is immutable so we have to create new string to do any changes in existing string to use anywhere

public class TestString{

public static void main(String[] args){

String a = "Java";
String b = new String(a);
String c = "Java";
String d = new String(a);

System.out.println("String a = " + a);
System.out.println("String b = " + b);
System.out.println("String c = " + c);

System.out.println("Result of a == b : " + (a == b));
System.out.println("Result of a == c : " + (a == c));
System.out.println("Result of b == c : " + (b == c));
System.out.println("Result of b == d : " + (b == d));
System.out.println("Result of a equals b : " + (a.equals(b)));
System.out.println("Result of a equals c : " + (a.equals(c)));
System.out.println(a.substring(2));//return from given index till end
System.out.println(a.substring(2));//return from given index till end
System.out.println(a.substring(1,3));//return from given index till end-1

String str=a.replace('a','r');
System.out.println(str);

String str2=a.replace("av","ir");//replace everywhere where av will be present
System.out.println(str2);

boolean bool=a.startsWith("Ja");// same way we can use endWith
System.out.println(bool);

System.out.println(a.indexOf("a"));//return the index of 1st occurence in given string
System.out.println(a.indexOf("va",1));//return the index of 1st occurence in given string from the index given in parameter and if its not found then it will return -1

//lastIndexOf(); will search from end and return the index where it finds particular string

//Escape Sequence Character- It use to inser some character in print line. eg: \n-Insert new line, \"- Insert double quote in between text inside println statement to avoid confusion or error
  
   String str5;
   str5="sdfvfffaaagggaaagbnm,";
   str5=str5.replace('a','r');
   //str5=str5+a;
   System.out.println(str5);
}
}

/*Output
=====

String a = Java
String b = Java
String c = Java
Result of a == b : false
Result of a == c : true

As in case of String b, Explicit Copy constructor is called, new reference is created for Java, 
while the same reference is allotted to C (Object pooling to enhance performance)
*/

/*In Java, the equals() method and the == operator are used to compare objects. 
 * The main difference is that string equals() method compares the content equality
 *  of two strings while the == operator compares the reference or memory location of objects in a heap, whether they point to the same location or not.
 */

