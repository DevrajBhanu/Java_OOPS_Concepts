package Package1;
//checked exception- which is checked during compile time like - I/0 Exception
// Unchecked Exception- checked duiring runtime like null pinter exceptions. ArrayIndexOutOfBound Exception

public class try_catch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try
		{
			int a=20;
			int b=a/0;
			System.out.println("Executing try block");// this statement will not be executed once exception occurs
			}
		catch(ArithmeticException e)
		{
			//System.out.println("Executing Catch block");
			System.out.println("Exception Occurred:"+e);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			//System.out.println("Executing Catch block");
			System.out.println("Exception Occurred:"+e);
		}
		catch(Exception e) //handles all exceptions which is checked at last once others exceptions are checked
		{
			System.out.println("Executing Catch block");
			System.out.println("Exception Occurred:"+e);
			
		}
	}

}
