package Package1;
/*
 *Annotation:Used to give extra information for metatype
 * Overiride--> Used to Annoate Overide methods
 * Deprecated--> Used to deprecate any method
 * SuppressWarnings-->USed to suppress if warning comes for deprecated method
 * FunctionalInterface--> Used to annotate functional interface which contains only one abstract method
 * 
 */
@FunctionalInterface
interface myfunctional
{
	void thismethod();
}
class Parent5
{
public void print()
{
	System.out.println("Parent Class");
	}
}
class child5 extends Parent5 implements myfunctional
{
	@Override
public void print()
{
	System.out.println("Overiddden method from Child Class");
	}
@Deprecated
public void print2()
{
	System.out.println("Deprecated Method");
	}
public void thismethod()
{
	System.out.println("Interface Method");
}
}

public class Annotations {
 @SuppressWarnings("depreciation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child5 obj=new child5();
		obj.print();
		obj.print2();
		

	}

}
