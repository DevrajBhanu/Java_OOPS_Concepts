package Package1;
/*
 * Rule 1: Super class method takes priority
   If a class extends another class and also implements an interface, 
   the super class and interface’s default methods are of the same signature 
   then the Super class’s method takes priority over an interface's default method.
 */
class Helloooooo {
    public void sayIt() {
        System.out.println("Hello");
    }
}
interface Hiii {
    default void sayIt() {
        System.out.println("Hi");
    }
}
class Interface4 extends Helloooooo implements Hiii {

    public void printMessage() {
        sayIt();
    }

    public static void main(String[] args) {
        new Interface4().printMessage(); // Prints 'Hello'
    }
}