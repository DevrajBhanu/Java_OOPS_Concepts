package Package1;

  enum Day
{
	SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday");// these all are instance/object of Day type whwich we can think it as datatype
	                                   //containing constant values which we can use anywhere, all are static , final
	  private String lower;
	  
	   public void display()
	  {
		  System.out.println(this.lower);
	  }
	  
	    
	 /* public void setname()
	  {
		  lower=this.name();
	  }*/
	  private Day(String lower)  // constructor is private bcoz we dont want it values get changed or extended with any other class
	  {
		  this.lower=lower;
		  System.out.println("Constructor Called");
		  
	  }
}

public class ennum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*System.out.println(Day.SUNDAY);
		
		Day today=Day.MONDAY;
		System.out.println(today.name());
		
	    int index=today.ordinal();
	    System.out.println("Index:"+ index);
	    
	    System.out.println(Day.valueOf("MONDAY")); // it check either that value is present or not and if its present
	                                               //then it return same value , so dont confuse as it will return any index
	    Day arr[]=Day.values();//it will return array storing all values
	    for(Day ele:arr)
	    {
	    	System.out.println(ele);
	    }
	    
	
	    today.setname();
	    today.display();
	    
	    */
		Day today=Day.MONDAY;
		//System.out.println(today.lower); it will work when lower variable will be public only
		today.display();

	    
		

	}

}
