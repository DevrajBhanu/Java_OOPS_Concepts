package Package1;

/*
 * When we create object of subclass then the constructor of parent class is called by itself first then 
 * contructor of subclass is called and forcefully if we want to call constructor of parent class we can use super keyword.
 * eg: super(10,20)--> this is to call paramterized constructor of base class but for default constructor it is called by itself
 */

class Parent
{   int x;
	Parent()
	{   //if we add super keyword here also then it will call default constructor of its parent class if its defined 
		// and this or super keyword should be defined in first ever line inside constructor
		System.out.println("Default Construcor from Parent class");
	}
	Parent(int x)
	{
		this.x=x;
		System.out.println("Construcor from Parent class of value x as: "+x);
	}
	
}


class Derived1 extends Parent
{
	Derived1(int x,int y)
	{    super(x);
		System.out.println("Construcor from Derived1 class of value y as: "+y);
	}
}
public class Constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derived1 d=new Derived1(10,20);

	}

}
