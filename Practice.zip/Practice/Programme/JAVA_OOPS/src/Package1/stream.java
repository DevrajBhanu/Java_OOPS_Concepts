package Package1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;

/*
 * Stream-> Streams API (in java.util.stream),Stream is A sequence of data elements which is about 
 * processing collections in a functional style:
 * 
 *Operation	   Type	                 Description
  filter()	   Intermediate	         Select elements based on a condition
  map()	       Intermediate	         Transform elements (e.g., convert cases)
  sorted()	   Intermediate	         Sort elements
  distinct()   Intermediate	         Remove duplicates
  limit()	   Intermediate	         Limit the number of elements
  forEach()	   Terminal	             Perform action on each element
  collect()	   Terminal	             Gather results into a collection
  reduce()	   Terminal	             Aggregate elements to a single value
 * 
 *
 */
public class stream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> ls=List.of("Ram","Syam","Jiyan");
		List<String> ls2=ls.stream().filter(x-> x.startsWith("J")).toList();
		System.out.println(ls2);
		
		List<Integer> ls3=List.of(7,1,1,4,7,3);
		List<Integer> ls4=ls3.stream().distinct().toList();
		System.out.println(ls4);
		
		
		
		

	}

}
