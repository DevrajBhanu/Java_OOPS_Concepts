package Package1;
/*
 * All the data members declared inside interface are final so we can't changes its value once 
 * defined
 * 
 * we can't create non abstract method inside interface
 * 
 * We can create only abstract method whose implementations are not there and we can create
 *  default methods with implementation
 *  
 *  we can create private and default methods also to reduce line of code in default method, as we
 *   can use private method inside default method in interface
 *   
 *  we cant create object of interface but we can make as reference of interface so in this case
 *   only interface method will be called by creating main class object implementing it 
 *   and we an use only overriden method in that interface same like inheritance we can think
 */

interface A
{
   public void areaA();	
   public void print();
}
interface B 
{   int cube=10; //by default it is final so we cnat change this variable value
	public void areaB();
	public void print();
}
class C
{  int radius=2;
	public void methodC()
	{
		System.out.println("Method from class C");
	}
}

public class Interface extends C implements A,B {
	public void areaA()
	{
		System.out.println("Area= "+(cube*cube*cube));
	}
	public void areaB()
	{
		System.out.println("Area= "+(radius*radius));
	}
	public void print()
	{
		System.out.println("Print func");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Interface obj=new Interface();
     obj.areaA();
     obj.areaB();
     obj.print();
     
	}

}
