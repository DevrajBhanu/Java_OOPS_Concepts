package Package1;

public class Protected_Access_Modifier {
	protected int n;
		protected void call()
		{
			System.out.println("Protected members");
		}
	}


