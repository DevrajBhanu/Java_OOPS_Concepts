package Package1;
/*Compile-Time Polymorphism in Java is also known as static polymorphism. 
 * This type of polymorphism is achieved by function overloading or operator overloading. 
 * 
 * Method overloading in Java means when there are multiple functions with the same name but 
 * different parameters then these functions are said to be overloaded. Functions can be 
 * overloaded by changes in the number of arguments or/and a change in the type of arguments.
 */


	// Method overloading By using
	// Different Types of Arguments 

	// Class 1
	// Helper class
	class Helper {

	    // Method with 2 integer parameters
	    static int Multiply(int a, int b)
	    {
	        // Returns product of integer numbers
	        return a * b;
	    }

	    // Method 2
	    // With same name but with 2 double parameters
	    static double Multiply(double a, double b)
	    {
	        // Returns product of double numbers
	        return a * b;
	    }
	}

	// Class 2
	// Main class
	class Compiletime_Polymorphism
	{
	    // Main driver method
	    public static void main(String[] args) {
	      
	        // Calling method by passing
	        // input as in arguments
	        System.out.println(Helper.Multiply(2, 4));
	        System.out.println(Helper.Multiply(5.5, 6.3));
	    }
	}


