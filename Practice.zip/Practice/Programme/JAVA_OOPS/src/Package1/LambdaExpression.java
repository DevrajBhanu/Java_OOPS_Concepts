package Package1;

interface lambda
{
	public void print(int a);
}
//we can write below function as
public class LambdaExpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		lambda obj=a -> {System.out.println("Print"+a);};
		 obj.print(1);
		 
		// Runnable r=()->{System.out.println("Thread Starting");};
		 //we can rewrite as:
		 Thread t=new Thread(()->System.out.println("Thread Starting"));
	}
}

	/*public class LambdaExpression {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			lambda obj=new lambda()
					{
				public void print()
				{
					System.out.println("Print");
				}
					};
					obj.print();
					
					
					 
			Runnable r=new Runnable()
		    {
			 public void run()
			 {
				 System.out.println("Thread Starting");
			 }
			 Thread t=new Thread(r);
		 };

		}*/



