package Package1;

public class Recurssion_Fibonacci {
   public static int  fibonacci(int n)
    {
	   if(n==0|| n==1) //base condition to avoid infinite time execution - Stack overflow error
	   {
		   return 1; 
	   }
	   
	   return n*fibonacci(n-1); // function calling is stored in stack and once all function calling completes it will start calculating from top most till last main method call
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
      int result=fibonacci(3);
      System.out.println(result);
	}

}
