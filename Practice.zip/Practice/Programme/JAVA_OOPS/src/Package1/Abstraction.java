package Package1;
 abstract class shape
 { 
	 public String name;
    abstract public void Area();
	  
    public shape(String name)
	 {
		 this.name=name; 
	 }
	 public String getName()
	 {
		 return name;
	 }
 }
 class Rectangle extends shape
 {   public int length,breadth;
	public Rectangle(String name,int length,int breadth) {
		super(name);
		this.length=length;
		this.breadth=breadth;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void Area() {
		// TODO Auto-generated method stub
		System.out.println("Area of "+super.getName()+" is  "+(length*breadth));
		
	}
 }
 class Circle extends shape
 {   public int radius;
	public Circle(String name,int radius) {
		super(name);
		this.radius=radius;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void Area() {
		// TODO Auto-generated method stub
		System.out.println("Area of "+super.getName()+" is  "+(3*radius*radius));
		
	}
 }
 

 public class Abstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Rectangle obj=new Rectangle("Rectangle",10,20);
     obj.Area();
     
     Circle obj2=new Circle("Circle",2);
     obj2.Area();     
	}

}
