package Package1;

class My extends Thread
{
	My(String name)
	{
		super(name);
	}
	public void run()
	{
		System.out.println("Thread is running");
	}
}

public class Thread_Constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		My t1=new My("Ceramic");
		t1.start();
		System.out.println("Thread name is "+t1.getName());

	}

}
