package Package1;
/*
 * We can create thread by 2 ways:  1.) By extending Thread class
 *                                  2.) By implementing Runnable Interface
 */

class Class1 extends Thread
{     int i=0;
	public void run()
	{ 
		while(i<=40)
		{
		System.out.println("Call from class1");
		i++;
		}
	}
}

class Class2 extends Thread
{     int i=0;
	
	public void run()
	{ 
		while(i<=40)
	{
	System.out.println("Call from class2");
	i++;
	}
	}
}
	
	
public class MultiThreading {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Class1 t1=new Class1();
		Class2 t2=new Class2();
		t1.start();
		t2.start();
		

	}

}
