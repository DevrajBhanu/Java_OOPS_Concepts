package Package2;
import Package1.*;

public class Protected_Access_Modifier2 extends Protected_Access_Modifier {
	public static void main(String args[])
	{
		Protected_Access_Modifier2 obj=new Protected_Access_Modifier2();
		obj.call();
		System.out.println(obj.n);
	}

}
