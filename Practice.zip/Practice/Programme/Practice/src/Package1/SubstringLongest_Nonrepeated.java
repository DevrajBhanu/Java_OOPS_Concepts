package Package1;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

 class length_call {
	public int charIndex(String s)
	{  Map<Character,Integer> charIndex=new HashMap<>();
	   int left=0,maxLength=0;
	  for(int right=0;right<s.length();right++)
	  {
		 if(charIndex.containsKey(s.charAt(right)))
		 {
			left=Math.max(left, charIndex.get(s.charAt(right))+1); 
		 }
	  
	  charIndex.put(s.charAt(right),right);
	  maxLength=Math.max(maxLength, right-left+1);
	  
	  } 
		
	  return maxLength;
	}

}
public class SubstringLongest_Nonrepeated
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
				
		length_call obj=new length_call();
		System.out.println(obj.charIndex(str));
	}
}
