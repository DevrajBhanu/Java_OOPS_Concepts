package Package1;

import java.util.Scanner;
import java.util.*;

//public-can be accessed anywhere

//we have to import main class package to class from other package to use private,protected and default

//private-can be accessed within the class it is defined

//protected-can be accessed within class , sub class defined in same package and from the class defined in different package using Inheritance

/*default-When no access modifier is specified for a class, method, or data member, it is said to be having the default access modifier by default.
          It can be accessed only within class or sub class defined in same package 
*/          
public class AcessSpecifier {
	 public static void main(String args[])
	 
	 {
		// char ch='a';
		 /*Short age=333333333333333;
		 System.out.println(age);*/ //error as value is out of short range
		// System.out.println(ch);
		
		 
		 //taking input from user using scanner class
		 Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number");
		 int a=sc.nextInt();
		 System.out.println(a);
		 
		/* boolean b=sc.hasNextInt(); used to check input given is integer or not
		 System.out.println(b);*/ 
		 
		 //Ternary Operator
		 int b=2>3?4:5;
		 System.out.println(b);
	 }

}
