package DSA_Package1;
import java.util.*;
import java.util.ArrayList;
import java.util.Scanner;

class call
{    int l;
	public void result()
	{  String result=new String("");
     ArrayList<String> araylist = new ArrayList<String>();
     araylist.add("Stone");
     araylist.add("Paper");
     araylist.add("Scissor");
     Random rndm = new Random(); 
     Scanner sc=new Scanner(System.in);
     
    do
    { 	String str2 = araylist.get(rndm.nextInt(araylist.size()));
	   System.out.print("Enter choice 1:");String str1=sc.next();
	 if(str1.equalsIgnoreCase("Stone")||str1.equalsIgnoreCase("Paper")||str1.equalsIgnoreCase("Scissor"))
	 {	 
			 if(str1.equalsIgnoreCase("Stone")&&str2.equalsIgnoreCase("Paper")||str1.equalsIgnoreCase("Paper")&&str2.equalsIgnoreCase("Stone"))
	   {
		   result="Paper";
	   }
	   else if(str1.equalsIgnoreCase("Stone")&&str2.equalsIgnoreCase("Scissor")||str1.equalsIgnoreCase("Scissor")&&str2.equalsIgnoreCase("Stone"))
	   {
		   result="Stone";
	   }
	   else if(str1.equalsIgnoreCase("Paper")&&str2.equalsIgnoreCase("Scissor")||str1.equalsIgnoreCase("Scissor")&&str2.equalsIgnoreCase("Paper"))
	   {
		   result="Scissor";
	   }
	   else if(str1.equalsIgnoreCase(str2))
	   {
		   result="Tie";
	   }
	   
			 System.out.println("Computer Choice:" + str2);
			 System.out.println("Result is:"+result);
			 
	}
	 else 
	 {
		 System.out.println("Invalid Input");
	 }
	 System.out.println("Do you want to continue? Enter 1 to continue or Enter 2");
	 l=sc.nextInt();
		 
 }   while(l==1);
    }
	
}

public class Rock_Paper_Scissor {
	public static void main(String args[])
	{
	
		call obj=new call();
		obj.result();
		
	}

}
