package DSA_Package1;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
//2 approach is there one by reversing the array & 2nd is by copying element to temporary array and shifting them and concate
/*
 * 1st Approach
 * void leftRotate(int[] arr, int d) {
    int n = arr.length;
    int[] temp = new int[d];
    // Step 1: Copy first d elements to temp
    for (int i = 0; i < d; i++) {
        temp[i] = arr[i];
    }
    // Step 2: Shift rest of the array to the left
    for (int i = d; i < n; i++) {
        arr[i - d] = arr[i];
    }
    // Step 3: Copy temp elements to end
    for (int i = 0; i < d; i++) {
        arr[n - d + i] = temp[i];
    }
}

 */
//2nd Approach
public class Rotate_Array_left {
	public static void reverse(int[] arr, int start, int end) {
	    while (start < end) {
	     int temp=arr[end];
	     arr[end]=arr[start];
	     arr[start]=temp;
	     start++;
	     end--;
	    }
	}

	static void leftRotate(int[] arr, int d) {
	    int n = arr.length;
	    d = d % n;  // In case d > n
	    reverse(arr, 0, d - 1);
	    reverse(arr, d, n - 1);
	    reverse(arr, 0, n - 1);
	    
	    	
	    System.out.print(Arrays.toString(arr));
	   
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rotate_Array_left.leftRotate(new int[] {2,3,4,5,6},2);

	}

}
