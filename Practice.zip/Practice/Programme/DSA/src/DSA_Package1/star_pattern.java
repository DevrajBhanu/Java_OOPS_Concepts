package DSA_Package1;
/*            n-i       i
 *    *  >> 3 space+ 1star
 *   **     2space+2star    
 *  ***     1space+3star
 * ****     0space+4star
 *      sop here all are having sum 4,   total we have n=4, where spaces are= n-i and star are i
 */    

public class star_pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=4;i>=0;i--)
		{
			for(int j=0;j<=4;j++)
			{
				if(j>=i)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
				
			}
			System.out.println();
		}     
	/*
	 * or we can write as
	 * int n=4;
	 * for(int i=1;i<=n;i++)
	 * {
	 *    for(int j=1;j<=n-i;j++)
	 *    {
	 *    System.out.print(" ");
	 *    }
	 *    for(int j=1;j<=i;j++)
	 *    {
	 *       System.out.print("*");
	 *    }
	 *   System.out.println();  
	 * }
	 */
	 
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
	
	
/*
 * 1
 * 0 1
 * 1 0 1
 * 0 1 0 1
 * 1 0 1 0 1    (explaination is in DSA_screenshot folder)
 */
	
      for(int i=1;i<=5;i++)
      {
    	  for(int j=1;j<=i;j++)
    	  {
    		  if((i+j)%2==0)
    				  {
    			   System.out.print("0");
    				  }
    		  else
    		  {
    			  System.out.print("1");
    		  }
    	  }
    	  System.out.println();
      }
      
        System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();

	
	
	
	
/* n=4(total no of row)   i          2*(n-i)       i
*     *      *	  i=1,   1star   +   space=6    + 1star   
*     **    **    i=2,   2star   +   space=4    + 2star   
*     ***  ***    i=3,   3star   +   space=2    + 3star
*     ********    i=4,   4star   +   space=0    + 4star
*     
*/ 
		int n=5;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=i;j++)
		{
			System.out.print("*");
		}
		for(int j=1;j<=(2*(n-i));j++)
				{
			      System.out.print(" ");
				}
			
		for(int j=1;j<=i;j++)
		{
		 System.out.print("*");
		}
		System.out.println();
	}
	
	
	
	System.out.println();
	System.out.println();
	System.out.println();
	System.out.println();
	
	

	
	
	
	/*
         *        *
         **      **
         ***    ***
         ****  ****
         **********
         **********
         ****  ****
         ***    ***
         **      **
         *        *     explaination is in screenshot
 
 */
	int n1=5;
	for(int i=1;i<=n1;i++)
	{
		for(int j=1;j<=i;j++)
		{
			System.out.print("*");
		}
		for(int j=1;j<=(2*(n1-i));j++)
				{
			      System.out.print(" ");
				}
			
		for(int j=1;j<=i;j++)
		{
		 System.out.print("*");
		}
		System.out.println();
	}
	for(int i=n1;i>=1;i--)
	{
		for(int j=i;j>=1;j--)
		{
			System.out.print("*");
		}
		for(int j=1;j<=(2*(n1-i));j++)
				{
			      System.out.print(" ");
				}
			
		for(int j=i;j>=1;j--)
		{
		 System.out.print("*");
		}
		System.out.println();
	}
	
 
}
}
