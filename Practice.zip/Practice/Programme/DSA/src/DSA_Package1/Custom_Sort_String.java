package DSA_Package1;

public class Custom_Sort_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="cba";
		String s2="abcbd";
		int c[]=new int[26];
		StringBuilder sb=new StringBuilder();
		
		for(char ch:s2.toCharArray())
		{
			if(s1.indexOf(ch) == -1)
			{
				sb.append(ch);
			}
			else {
				c[ch-'a']++;
			}
		}
         for(char ch:s1.toCharArray())
         {
        	int i=c[ch-'a'];
        	while(i-->0)
        	{
        		sb.append(ch);
        	}
         }
         System.out.println(sb.toString());
	}

}
