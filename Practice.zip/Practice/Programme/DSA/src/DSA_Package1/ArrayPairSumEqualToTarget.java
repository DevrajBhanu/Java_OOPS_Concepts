package DSA_Package1;

import java.util.Arrays;
import java.util.HashSet;

public class ArrayPairSumEqualToTarget {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * [-1,3,4,-2,6,1,0]   target=2; y=2-x;
		 * -1-->  2-(-1)=3--> not in hasset so add -1 in hashset
		 * next element-->3 --> 2-3=-1 is in hashset so print the pairs (num, compliment)
		 * 4->2-4=-2(add in hashset)
		 */
		int arr[]= {-1,2,4,2,6,-2,3,0};int target=2;
		/*Integer arr[]= {-1,2,4,2,6,-2,3,0};int target=2;
		 Arrays.sort(arr, (a, b) -> b - a);
		for(int nums:arr)
		{
			System.out.print("Sorted array"+nums);
		}*/
		
		HashSet<Integer> hs=new HashSet<Integer>();
		for(int nums:arr)
		{
			int compliment=target-nums;
			if(hs.contains(compliment))
			{
				System.out.println("Pairs are: "+nums+","+compliment);
			}
			else
			{
				hs.add(nums);
			}
		}
		

	}

}
