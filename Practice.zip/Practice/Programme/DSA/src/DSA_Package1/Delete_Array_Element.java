package DSA_Package1;

import java.util.Arrays;

public class Delete_Array_Element {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[]= {1,2,3,4,4,5,6};
		int element=4;int count=0;
		for(int nums:arr)
		{
			if(nums==element)
				count++;
		}
		int arr2[]=new int[arr.length-count];
		int index=0;
		for(int nums:arr)
		{
			if(nums!=element)
			{	arr2[index]=nums;
			    index++;}
		}
		System.out.println(Arrays.toString(arr2));
		
		
	}

}
