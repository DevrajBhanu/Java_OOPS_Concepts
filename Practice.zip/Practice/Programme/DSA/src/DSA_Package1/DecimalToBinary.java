package DSA_Package1;

public class DecimalToBinary {
	public static String binarytoDec(int n)
	{
		String str ="";
		   while(n!=0)
		   {
		   int d=n%2;
		   str=d+str;// it will append in reverse order
		   n=n/2;
		   }
		   return str;
	}
	public static int DectoBinary(String str)
	{
		int res=0;   int power=0;
		for(int i=str.length()-1;i>=0;i--)
		   {
			 res+=(int)(Math.pow(2,power)*Character.getNumericValue((str.charAt(i))));
			 power++;
					 
		   }
		   
		   return res;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       System.out.println("BinaryToDecimal: "+binarytoDec(17));
       System.out.println("BinaryToDecimal: "+DectoBinary("10001"));
	}
	/*
	 * we can use stack also
	 * Stack<Integer> stack = new Stack<>();

        while (n != 0) {
            stack.push(n % 2);
            n = n / 2;
        }

        StringBuilder binary = new StringBuilder();
        while (!stack.isEmpty()) {
            binary.append(stack.pop());
        }
	 */
	
	
	

}
