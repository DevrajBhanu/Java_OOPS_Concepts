package DSA_Package1;

public class Rough {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=30;int m=4;int sum1=0,sum2=0;
		for(int i=1;i<=n;i++)
		{
			if(i%m==0)
			{
				sum1+=i;
			}
			else
			{
				sum2+=i;
			}
		}
		System.out.println(sum2-sum1);
		/*
		 * int n,m
		 * x=n/m;
		 * int sum1=m*(x*(x+1)/2);
		 */
			

	}

}
