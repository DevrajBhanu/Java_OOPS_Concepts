package DSA_Package1;

/*
 *   Linear Search
 *   for(int i=0;i<=n;i++)
 *   {
 *      if(arr[i]==element)
 *      {
 *        return 1;
 *      }
 *      else return -1;
 *       
 *        
 */
class Search
{
	public void binarySearch(int element)
	{
		int arr[]= {2,4,10,10,10,11,12,15,18,21};
		int front=0;
		int tail=arr.length-1;
		
	     while(front <= tail)
	     { 	 
		 int  mid=(front+tail)/2;
		 if(arr[mid]==element)
		 {
			 System.out.println("Element is present at index: "+mid);
			 return;
		 }
		 else if(element<arr[mid])
		 {
			 tail=mid-1;	 
		 }
		 else if(element>arr[mid])
		 {
			 front=mid+1;	 
		 }	
	} 
   System.out.println("Element not found");
}
}
public class Linear_Binary_Search {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Search obj=new Search();
		obj.binarySearch(10);

	}

}
