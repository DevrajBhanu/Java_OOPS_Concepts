package DSA_Package1;

import java.util.Arrays;

public class Remove_Duplicates_Sorted_array
{
	public static void main(String args[])
	{ /* int index=1;int count=0;int arr[]= {1,2,3,3,3,4,4,4,5,6,6};

		for(int nums:arr)
		{
			if(index<arr.length)
			{  
				if(nums==arr[index++])
				count++;
			}
		}
		System.out.println("Number of duplicates: "+count);
		
		int arr2[]=new int[arr.length-count];
		 int index2=0;
		for(int i=0;i<arr.length;)
		{    
			arr2[index2++]=arr[i];
			int pointer=i+1;
			while (pointer < arr.length && arr[i] == arr[pointer])
			{   
				pointer++;
			}
			i=pointer;
		}
		System.out.println(Arrays.toString(arr2));
		*/
		
		int pointer=1;int arr[]= {1,2,3,3,3,4,4,4,5,6,6};
		for(int i=1;i<arr.length;i++)
		{
		   if(arr[i]!=arr[i-1])
		   {
			   pointer+=1;
			  arr[pointer-1]=arr[i];
		   }
		}
		System.out.println(pointer);
		for(int i=0;i<=pointer;i++) {
			System.out.print(arr[pointer]);
		}
		
		
		
	}
			

}
