package DSA_Package1;

public class Length_of_last_word {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=" A flying Jattt    ";int res=0;
		for(int i=s.length()-1;i>=0;i--)
		{
			if(s.charAt(i)!=' ')
			{
				res++;
			}
			else if(res!=0)
			{
				break;
			}
		}
		System.out.println(res);

	}

}
