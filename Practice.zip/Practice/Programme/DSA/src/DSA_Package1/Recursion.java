package DSA_Package1;

public class Recursion {
	//print 1 to n using recursion
	
	public static void oneton(int n)
	{  
		if(n==1)
		{System.out.print(n);
			return;			}
		else {
			oneton(n-1);
			System.out.print(n);
		}
	}
	public static void ntoOne(int n)
	{  
		if(n==1)
		{   System.out.print(n);
			return;			}
		else {
			System.out.print(n);
			ntoOne(n-1);
			
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*factorial
		 * int fact(int n)
		 * { 
		 *   if(n!=0)
		 *   return n*fact(n-1);
		 *   
		 *   else return1;
		 * }
		 *
		 */
		Recursion.oneton(5);
		System.out.println();
		Recursion.ntoOne(5);

	}

}
