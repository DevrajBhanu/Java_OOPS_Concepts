package DSA_Package1;

import java.util.Arrays;

public class Sorted_Square_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*      Brute Approach
		int arr[]= {-4,-3,0,7,5,2};
		int arr2[]=Arrays.stream(arr).map(i->i*i).toArray();
		Arrays.sort(arr2);
		System.out.println(Arrays.toString(arr2));
		*/
		/*    2nd Approach
		 * public static int[] sortedSquares(int[] nums) {
        int[] sqArr = new int[nums.length];
        for(int l=0,r=nums.length-1,i=r; i>=0; i--) {
            sqArr[i] = Math.abs(nums[l]) > Math.abs(nums[r]) ? nums[l++] : nums[r--];
            sqArr[i] *= sqArr[i];
        }
        return sqArr;
    }
		 */
		int arr[]= {-8,-3,0,2,5,7};
		int arr2[]=new int[arr.length];
		int l=0;int r=arr.length-1;
		for(int i=arr.length-1;i>=0;i--)
		{
		if(Math.abs(arr[l])>Math.abs(arr[r]))
		 {
			 arr2[i]=arr[l]*arr[l];
			 l++;
		 }
		 else if(Math.abs(arr[l])<Math.abs(arr[r]))
		 {
			 arr2[i]=arr[r]*arr[r];
			 r--;
		 }
		}
		
	System.out.println(Arrays.toString(arr2));

}
}

