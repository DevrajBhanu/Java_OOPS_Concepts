package DSA_Package1;

import java.util.Arrays;

public class count_each_character_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="apple";
		int c[]=new int[26];
		for(char i:s.toCharArray())
		{  
			c[i-'a']++;
			
		}
          
          System.out.println(Arrays.toString(c));
	}

}
