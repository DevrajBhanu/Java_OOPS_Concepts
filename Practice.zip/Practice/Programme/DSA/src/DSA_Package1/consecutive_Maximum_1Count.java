package DSA_Package1;

public class consecutive_Maximum_1Count {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {0,1,1};
		int c=0;int temp=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==1)
			{
				temp++;
				if(temp>=c)
				   {
				     c=temp;
				   }
			   
		    }
			else 
			   {
			     temp=0;
			     
			   }
               
	   }
      System.out.println("Maximum Consecutive 1 is: "+c);
}
}
